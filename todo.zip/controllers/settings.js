module.exports = {
    port: '3030',
    // Connect to MonggoDb, 
    // example atlas : mongodb+srv://zekaistodo:password@clusters.rqvdo.mongodb.net/Database?retryWrites=true&w=majority
    // example local : mongodb://127.0.0.1:27017
    dbURI: 'mongodb+srv://huzaifa:Mongo0900@cluster0.legimcc.mongodb.net/?retryWrites=true&w=majority' 
}